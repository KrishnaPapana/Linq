﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Solid
{
    class InterfacesSegregationPrinciple
    {
        //The Interface Segregation Principle states that 
        //“Clients should not be forced to implement any methods they don’t use.
        //Rather than one fat interface, numerous little interfaces are preferred based on groups of methods with each interface serving one submodule“.
    }
    
    
    //Before Interfaces Segregation Principle

    public interface IPrintTasks
    {
        bool PrintContent(string content);
        bool PhotoCopyContent(string content);
        bool PrintDuplexContent(string content);
    }

    public class HpLaserJet : IPrintTasks
    {
        public bool PrintContent(string content)
        {
            Console.WriteLine("Print Done");
            return true;
        }
        public bool PhotoCopyContent(string content)
        {
            return false;
        }
        public bool PrintDuplexContent(string content)
        {
            Console.WriteLine("Print Done ");
            return true;
        }
    }

    public class CannonNg2470 : IPrintTasks
    {
        public bool PrintContent(string content)
        {
            Console.WriteLine("Print Done");
            return true;
        }
        public bool PhotoCopyContent(string content)
        {
            Console.WriteLine("Copy Done");
            return true;
        }
        public bool PrintDuplexContent(string content)
        {
            return false;
        }
    }


    // After Interface Segregation Principle

    interface IPrintContent
    {
        bool PrintContent(string content);
    }
    interface IPhotoCopyContent
    {
        bool PhotoCopyContent(string content);
    }
    interface IPrintDuplexContent
    {
        bool PrintDuplexContent(string content);
    }

    public class HPLaserJet : IPrintContent, IPrintDuplexContent
    {
        public bool PrintContent(string content)
        {
            Console.WriteLine("Print Done");
            return true;
        }
        
        public bool PrintDuplexContent(string content)
        {
            Console.WriteLine("Print Done ");
            return true;
        }
    }

    public class CannonNG2470 : IPrintContent,IPhotoCopyContent
    {
        public bool PrintContent(string content)
        {
            Console.WriteLine("Print Done");
            return true;
        }
        public bool PhotoCopyContent(string content)
        {
            Console.WriteLine("Copy Done");
            return true;
        }
    }
}
