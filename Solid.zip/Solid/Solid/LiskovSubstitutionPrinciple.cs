﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Solid
{
    class LiskovSubstitutionPrinciple
    {
        //Ability to replace any instance of a parent class with an instance of one of its child classes
        //without negative side effects
        static void Main(string[] args)
        {
            //before LSP

            var numbers = new int[] { 1, 2, 4, 5, 6, 7, 8 };
            SumCalculator sum = new SumCalculator(numbers);
            Console.WriteLine("sum of numbers: "+ sum.Calculate());
            EvenNumbersSumCalculator eSum = new EvenNumbersSumCalculator(numbers);
            Console.WriteLine("\nSum of Even Numbers: " + eSum.Calculate());

            //After LSP
            //Uncomment the below lines 

            //var numbers = new int[] { 1, 2, 4, 5, 6, 7, 8 };
            //Calculator sum = new NewSumCalculator(numbers);
            //Console.WriteLine("sum of numbers: " + sum.Calculate());
            //Calculator evenSum = new NewEvenNumbersSumCalculator(numbers);
            //Console.WriteLine("\nSum of Even Numbers: " + evenSum.Calculate());


        }
    }
    //Before LSP
    public class SumCalculator
    {
        protected readonly int[] _numbers;
        public SumCalculator(int[] numbers)
        {
            _numbers = numbers;
        }
        public int Calculate()
        {
            return _numbers.Sum();
        }
    }
    public class EvenNumbersSumCalculator : SumCalculator
    {
        public EvenNumbersSumCalculator(int[] numbers):base(numbers)
        {

        }
        public new int Calculate()
        {
            return _numbers.Where(x => x % 2 == 0).Sum();
        }
    }

    //After LSP
    public abstract class Calculator
    {
        protected readonly int[] _numbers;
        public Calculator(int[] numbers)
        {
            _numbers = numbers;
        }
        public abstract int Calculate();
        
    }

    public class NewSumCalculator: Calculator
    {
        public NewSumCalculator(int[] numbers):base(numbers)
        {

        }
        public override int Calculate()
        {
            return _numbers.Sum();
        }
    }
    public class NewEvenNumbersSumCalculator : NewSumCalculator
    {
        public NewEvenNumbersSumCalculator(int[] numbers) : base(numbers)
        {

        }
        public new int Calculate()
        {
            return _numbers.Where(x => x % 2 == 0).Sum();
        }
    }

}
