﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Solid
{
    class SingleResponsibilityPrinciple
    {
        //A reason to change
        //A class or method should have only one reason to change.

        //Single Responsibility
        //A class or method should have only a single responsibility.

        //Means A class or method should have only one type of thing or work to do 
    }

    public interface IReport
    {
        void AddEntryAt(int index);
        void RemoveEntryAt(int index);
        void SaveToFile(string directoryPath, string fileName);
    }

    public interface IReportAfterSRP
    {
        void AddEntryAt(int index);
        void RemoveEntryAt(int index);
        
    }

    public interface IReportSaver
    {
        void SaveToFile(string directoryPath, string fileName);
    }

}
