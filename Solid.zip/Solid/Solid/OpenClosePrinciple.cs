﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Solid
{
    class OpenClosePrinciple
    {
        //The principle says “software entities(classes, modules, functions, etc.) should be open for extension, but closed for modification”.
        //So in simple words it says that an implementation(of a class or function), once created, should be closed for further modification, 
        //in other words one should not modify an implementation(of a class or function) of logic and/or functionality.
        //One can do refactoring or resolve errors of implementation (of a class or function) but the implementation(of a class or function) is open for extension, 
        //in other words one can extend the implementation(of a class or function) of logic and/or functionality.
    }

    //Before OpenClosePrinciple
    public class EmployeeReport
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Level { get; set; }
        public int WorkingHours { get; set; }
        public int HourlyRate { get; set; }
    }

    public class SalaryCalculator
    {
        private readonly IEnumerable<EmployeeReport> _employeReport;
        public SalaryCalculator(List<EmployeeReport> employeeReport)
        {
            _employeReport = employeeReport;
        }
        public double CalculateTotalSalaries()
        {
            double totalSalaries = 0;
            foreach(var devReport in _employeReport)
            {
                totalSalaries += devReport.HourlyRate * devReport.WorkingHours;
            }
            return totalSalaries;
        }
    }
    //After Open Close Principle
    public abstract class BaseSalaryCalculator
    {
        protected EmployeeReport EmployeeReport { get; set; }
        public BaseSalaryCalculator(EmployeeReport employeeReport)
        {
            EmployeeReport = employeeReport;
        }
        public abstract double CalculateSalary();
    }

    public class SeniorDevSalaryCalculator : BaseSalaryCalculator
    {
        public SeniorDevSalaryCalculator(EmployeeReport report) : base(report) { }
        public override double CalculateSalary()
        {
            //implementation
            throw new NotImplementedException();
        }
    }

    public class JuniorDevSalaryCalculator : BaseSalaryCalculator
    {
        public JuniorDevSalaryCalculator(EmployeeReport report) : base(report) { }
        public override double CalculateSalary()
        {
            //implementation
            throw new NotImplementedException();
        }
    }
}
