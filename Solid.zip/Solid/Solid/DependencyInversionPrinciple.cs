﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Solid
{
    class DependencyInversionPrinciple
    {
        //High-level modules should not depend on low-level modules.
        //Both should depend on abstractions.Abstractions should not depend on details.
        //Details should depend on abstractions.
        //This principle is primarily concerned with reducing dependencies among the code modules
    }
    public class BusinessLogicLayer
    {
        private readonly DataAccessLayer Dal;

        public BusinessLogicLayer()
        {
            Dal = new DataAccessLayer();
        }

        public void Save(Object details)
        {
            Dal.save(details);
        }

    }

    public class BusinessLogicLayerWithDependencyInversionPrinciple
    {
        private readonly IRepositoryLayer RL;

        //public BusinessLogicLayerWithDependencyInversionPrinciple(IRepositoryLayer repositoryLayer)
        //{
        //    RL = repositoryLayer;
        //}

        public void Save(object details)
        {
            RL.Save(details);
        }

    }
}
