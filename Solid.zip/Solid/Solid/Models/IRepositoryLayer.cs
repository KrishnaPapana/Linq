﻿namespace Solid
{
    internal interface IRepositoryLayer
    {
        void Save(object details);
    }
}