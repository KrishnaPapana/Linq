﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Solid.Models
{
    class DataAccessLayerWithDependency : IRepositoryLayer
    {
        public void Save(object details)
        {
            throw new NotImplementedException();
        }
    }
}
