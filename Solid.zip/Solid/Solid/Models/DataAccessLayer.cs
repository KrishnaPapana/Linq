﻿using System;

namespace Solid
{
    internal class DataAccessLayer
    {
        internal void save(object details)
        {
            throw new NotImplementedException();
        }
    }
}