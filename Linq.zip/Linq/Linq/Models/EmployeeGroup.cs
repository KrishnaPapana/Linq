﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Linq.Models
{
    class EmployeeGroup
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public string Department { get; set; }
        public int Salary { get; set; }

        public static List<EmployeeGroup> GetAllEmployees()
        {
            return new List<EmployeeGroup>()
        {
            new EmployeeGroup { ID = 1, Name = "Mark", Gender = "Male",
                                         Department = "IT", Salary = 45000 },
            new EmployeeGroup { ID = 2, Name = "Steve", Gender = "Male",
                                         Department = "HR", Salary = 55000 },
            new EmployeeGroup { ID = 3, Name = "Ben", Gender = "Male",
                                         Department = "IT", Salary = 65000 },
            new EmployeeGroup { ID = 4, Name = "Philip", Gender = "Male",
                                         Department = "IT", Salary = 55000 },
            new EmployeeGroup { ID = 5, Name = "Mary", Gender = "Female",
                                         Department = "HR", Salary = 48000 },
            new EmployeeGroup { ID = 6, Name = "Valarie", Gender = "Female",
                                         Department = "HR", Salary = 70000 },
            new EmployeeGroup { ID = 7, Name = "John", Gender = "Male",
                                         Department = "IT", Salary = 64000 },
            new EmployeeGroup { ID = 8, Name = "Pam", Gender = "Female",
                                         Department = "IT", Salary = 54000 },
            new EmployeeGroup { ID = 9, Name = "Stacey", Gender = "Female",
                                         Department = "HR", Salary = 84000 },
            new EmployeeGroup { ID = 10, Name = "Andy", Gender = "Male",
                                         Department = "IT", Salary = 36000 }
        };
        }
    }
}
