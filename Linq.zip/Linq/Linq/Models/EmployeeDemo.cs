﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Linq.Models
{
    class EmployeeDemo
    {
        public string Name { get; set; }
        public string JobTitle { get; set; }
        public string City { get; set; }
    }
}
