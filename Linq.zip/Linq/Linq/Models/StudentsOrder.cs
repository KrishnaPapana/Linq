﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Linq.Models
{
    class StudentsOrder
    {
        public int StudentID { get; set; }
        public string Name { get; set; }
        public int TotalMarks { get; set; }

        public static List<StudentsOrder> GetAllStudents()
        {
            List<StudentsOrder> listStudents = new List<StudentsOrder>
        {
            new StudentsOrder
            {
                StudentID= 101,
                Name = "Tom",
                TotalMarks = 800
            },
            new StudentsOrder
            {
                StudentID= 102,
                Name = "Mary",
                TotalMarks = 900
            },
            new StudentsOrder
            {
                StudentID= 103,
                Name = "Valarie",
                TotalMarks = 800
            },
            new StudentsOrder
            {
                StudentID= 104,
                Name = "John",
                TotalMarks = 800
            },
        };

            return listStudents;
        }
    }
}
