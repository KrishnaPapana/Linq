﻿using System;
using System.Linq;
using System.Collections.Generic;
using Linq.Models;
using System.Collections;

namespace Linq
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--------------------Welcome to Linq----------------------------\n");
            //uncomment and comment each method 
            
            BasicLinq();
            //ExtensionMethod();
            //AggrigateOperators();
            //RestrictionOperators();
            //ProjectileOperators();
            //ProjectileSelectMany();
            //OrderingOperators();
            //PartationingOperators();
            //ConversionOperators();
            //GroupingOperators();
        }

        
        public static void BasicLinq()
        {
            //Linq Queries

            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            Console.WriteLine("Simple Linq Query");
            var result = from num in numbers
                         where (num % 2) == 0
                         select num;
            foreach (int i in result)
            {
                Console.WriteLine(i);
            }

            // LINQ Standard Query Operators are select,from,where,orderby,join,groupby
            Console.WriteLine("\n********************************************************************************************");
            //LINQ query using Lambda Expressions.

            IEnumerable<Student> students = Student.GetAllStudents()
                                            .Where(student => student.Gender == "Male");
            Console.WriteLine("\nLINQ query using Lambda Expressions.\n");
            foreach (var student in students)
            {
                Console.WriteLine("Id = " + student.ID + " Name = " + student.Name + " Gender = " + student.Gender);
            }


            //LINQ query using using SQL like query expressions

            Console.WriteLine("\nLINQ query using using SQL like query expressions\n");
            IEnumerable<Student> studentsQuery = from student in Student.GetAllStudents()
                                                 where student.Gender == "Female"
                                                 select student;
            foreach (var student in studentsQuery)
            {
                Console.WriteLine("Id = " + student.ID + " Name = " + student.Name + " Gender = " + student.Gender);
            }
        }

        
        
        public static void ExtensionMethod()
        {
            Console.WriteLine("\n********************************************************************************************\n");

            Console.WriteLine("\nExtension Methods\n");

            //https://csharp-video-tutorials.blogspot.com/2014/07/part-3-extension-methods-in-c.html

            //Let us understand what this definition actually means.
            //LINQ's standard query operators (select, where etc ) are implemented in Enumerable class as extension methods on the IEnumerable<T> interface.

            List<int> Numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            IEnumerable<int> EvenNumbers = Numbers.Where(n => n % 2 == 0);

            foreach (int i in Numbers)
            {
                Console.WriteLine(i);
            }
            //In spite of Where() method not belonging to List < T > class,
            //we are still able to use it as though it belong to List<T> class. 
            //This is possible because Where() method is implemented as extension method in IEnumerable<T> interface and List<T> implements IEnumerable<T> interface.

            Console.WriteLine("\nOur Own Extension Method\n");

            string strName = "yoo";
            string resultString = strName.ChangeFirstLetterCase();

            Console.WriteLine(resultString);

            Console.WriteLine("\n********************************************************************************************\n");
        }

        
        
        
        public static void AggrigateOperators()
        {
            Console.WriteLine("LINQ Standard Query Operators also called as LINQ extension methods can be broadly classified into the following categories\n Aggregate Operators\n Grouping Operators\n Restriction Operators\n Projection Operators\n Set Operators\n Partitioning Operators\n Conversion Operators\n Element Operators\n Ordering Operators\n Generation Operators\n Query Execution\n Join Operators\n Custom Sequence Operators\n Quantifiers Operators\n Miscellaneous Operators");



            Console.WriteLine("\n********************************************************************************************\n");

            //https://csharp-video-tutorials.blogspot.com/2014/07/part-4-linq-aggregate-functions.html

            Console.WriteLine("Aggregate Operators\n\n  Min\n  Max\n  Sum\n  Count\n  Average");

            int[] Numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            int smallestNumber = Numbers.Min();
            int smallestEvenNumber = Numbers.Where(n => n % 2 == 0).Min();

            int largestNumber = Numbers.Max();
            int largestEvenNumber = Numbers.Where(n => n % 2 == 0).Max();

            int sumOfAllNumbers = Numbers.Sum();
            int sumOfAllEvenNumbers = Numbers.Where(n => n % 2 == 0).Sum();

            int countOfAllNumbers = Numbers.Count();
            int countOfAllEvenNumbers = Numbers.Where(n => n % 2 == 0).Count();

            double averageOfAllNumbers = Numbers.Average();
            double averageOfAllEvenNumbers = Numbers.Where(n => n % 2 == 0).Average();

            Console.WriteLine("\nSmallest Number = " + smallestNumber);
            Console.WriteLine("\nSmallest Even Number = " + smallestEvenNumber);

            Console.WriteLine("\nLargest Number = " + largestNumber);
            Console.WriteLine("\nLargest Even Number = " + largestEvenNumber);

            Console.WriteLine("\nSum of All Numbers = " + sumOfAllNumbers);
            Console.WriteLine("\nSum of All Even Numbers = " + sumOfAllEvenNumbers);

            Console.WriteLine("\nCount of All Numbers = " + countOfAllNumbers);
            Console.WriteLine("\nCount of All Even Numbers = " + countOfAllEvenNumbers);

            Console.WriteLine("\nAverage of All Numbers = " + averageOfAllNumbers);
            Console.WriteLine("\nAverage of All Even Numbers = " + averageOfAllEvenNumbers);


            string[] countries = { "India", "USA", "UK" };

            int minCount = countries.Min(x => x.Length);
            int maxCount = countries.Max(x => x.Length);

            Console.WriteLine
                   ("\nThe shortest country name has {0} characters in its name", minCount);
            Console.WriteLine
                   ("\nThe longest country name has {0} characters in its name", maxCount);

            Console.WriteLine("\nAggregate Function\n");
            string[] Countries = { "India", "US", "UK", "Canada", "Australia" };

            string resultCountries = Countries.Aggregate((a, b) => a + ", " + b);

            Console.WriteLine(resultCountries);

            //How Aggregate() function works?
            // Step 1: First "India" is concatenated with "US" to produce result "India, US"
            // Step 2: Result in Step 1 is then concatenated with "UK" to produce result "India, US, UK"
            // Step 3: Result in Step 2 is then concatenated with "Canada" to produce result "India, US, UK, Canada"
            // This goes on until the last element in the array to produce the final single string "India, US, UK, Canada, Australia"

            int resultAgg = Numbers.Aggregate((a, b) => a + b);

            Console.WriteLine("\nSum Of All Numbers Upto 10 is = " + resultAgg);
        }
        
        
        
        
        
        
        
        public static void RestrictionOperators()
        {
            Console.WriteLine("\n********************************************************************************************\n");
            Console.WriteLine("Restriction Operators");
            //https://csharp-video-tutorials.blogspot.com/2014/07/part-6-restriction-operators-in-linq_8.html

            //The WHERE standard query operator belong to Restriction Operators category in LINQ.Just like SQL, 
            //the WHERE standard query operator in LINQ is used to filter rows. 
            //The filter expression is specified using a predicate.
            //A predicate is a function to test each element for a condition.

            List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            IEnumerable<int> evenNumbers = numbers.Where(num => num % 2 == 0);

            foreach (int evenNumber in evenNumbers)
            {
                Console.WriteLine(evenNumber);
            }

            // Using SQL like syntax
            IEnumerable<int> evenNumbersSql = from num in numbers
                                           where num % 2 == 1
                                           select num;
            Console.WriteLine("\nUsing Sql Like Syntax\n");
            foreach (int evenNumber in evenNumbersSql)
            {
                Console.WriteLine(evenNumber);
            }

            Console.WriteLine("\nUsing Own Predicate Function\n");
            IEnumerable<int> evenNumbersPre = numbers.Where(num => IsEven(num));
            foreach (int evenNumber in evenNumbersSql)
            {
                Console.WriteLine(evenNumber);
            }

            Console.WriteLine("\nUsing second Where type\n");
            var evenNumberIndex = numbers
                .Select((num, index) => new { Number = num, Index = index })
                .Where(x => x.Number % 2 == 0);

            foreach (var evenNumber in evenNumberIndex)
            {
                Console.WriteLine(evenNumber.Number+"-"+evenNumber.Index );
            }

            Console.WriteLine("\nSelecting Indexes\n");
            IEnumerable<int> evenNumberIndexPositions = numbers
                .Select((num, index) => new { Number = num, Index = index })
                .Where(x => x.Number % 2 == 0)
                .Select(x => x.Index);

            foreach (int evenNumber in evenNumberIndexPositions)
            {
                Console.WriteLine(evenNumber);
            }

        }

        public static bool IsEven(int number)
        {
            if (number % 2 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        
        
        
        
        
        
        public static void ProjectileOperators()
        {
            //https://csharp-video-tutorials.blogspot.com/2014/07/part-7-projection-operators-in-linq_9.html
            Console.WriteLine("\n***********************************Projectile Operators******************************************\n");
            //Projection Operators(Select &SelectMany) are used to transform the results of a query.
            //Select clause in SQL allows to specify what columns we want to retrieve. 
            //In a similar fashion LINQ SELECT standard query operator allows us to specify what properties we want to retrieve.
            //It also allows us to perform calculations.

            Console.WriteLine("\nRetrieves just the EmployeeID property of all employees\n");
            IEnumerable<int> employeeIds = Employee.GetAllEmployees().Select(emp => emp.EmployeeID);
            foreach (int id in employeeIds)
            {
                Console.WriteLine(id);
            }

            Console.WriteLine("\nProjects FirstName &Gender properties of all employees into anonymous type.\n");
            var result = Employee.GetAllEmployees().Select(emp => new { FirstName = emp.FirstName, Gender = emp.Gender});
            foreach (var v in result)
            {
                Console.WriteLine(v.FirstName + " - " + v.Gender);
            }


            Console.WriteLine("\nComputes FullName and MonthlySalay of all employees and projects these 2 new computed properties into anonymous type.\n");
            var result1 = Employee.GetAllEmployees().Select(emp => new
            {
                FullName = emp.FirstName + " " + emp.LastName,
                MonthlySalary = emp.AnnualSalary / 12
            });

            foreach (var v in result1)
            {
                Console.WriteLine(v.FullName + " - " + v.MonthlySalary);
            }

            Console.WriteLine("\nGive 10% bonus to all employees whose annual salary is greater than 50000 and project all such employee's FirstName, AnnualSalay and Bonus into anonymous type.\n");
            var result2 = Employee.GetAllEmployees()
                         .Where(emp => emp.AnnualSalary > 50000)
                         .Select(emp => new
                         {
                            Name = emp.FirstName,
                            Salary = emp.AnnualSalary,
                            Bonus = emp.AnnualSalary * .1
                         });

            foreach (var v in result2)
            {
                Console.WriteLine(v.Name + " : " + v.Salary + " - " + v.Bonus);
            }
        }


        
        
        
        
        
        public static void ProjectileSelectMany()
        {
            Console.WriteLine("\n******************************************************************************\n");
            
            //https://csharp-video-tutorials.blogspot.com/2014/07/part-8-selectmany-operator-in-linq.html
            
            //SelectMany Operator belong to Projection Operators category.
            //It is used to project each element of a sequence to an IEnumerable<T> and flattens the resulting sequences into one sequence.
            
            Console.WriteLine("\nProjects all subject strings of a given a student to an IEnumerable<string>.\n");

            IEnumerable<string> allSubjects = Students.GetAllStudetns().SelectMany(s => s.Subjects);
            foreach (string subject in allSubjects)
            {
                Console.WriteLine(subject);
            }

            Console.WriteLine("\nRewriting Example using SQL like syntax.\n");
            IEnumerable<string> allSubjectsSql = from student in Students.GetAllStudetns()
                                              from subject in student.Subjects
                                              select subject;

            foreach (string subject in allSubjectsSql)
            {
                Console.WriteLine(subject);
            }

            Console.WriteLine("\nProjects each string to an IEnumerable<char>.\n");
            string[] stringArray =
            {
                "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                "0123456789"
            };

            IEnumerable<char> result = stringArray.SelectMany(s => s);

            foreach (char c in result)
            {
                Console.WriteLine(c);
            }

            Console.WriteLine("\nRewriting Example using SQL like syntax.\n");


            IEnumerable<char> result1 = from s in stringArray
                                       from c in s
                                       select c;

            foreach (char c in result1)
            {
                Console.WriteLine(c);
            }

            Console.WriteLine("\nSelects only the distinct subjects\n");
            IEnumerable<string> allSubjectsDis = Students.GetAllStudetns()
                                              .SelectMany(s => s.Subjects).Distinct();
            foreach (string subject in allSubjectsDis)
            {
                Console.WriteLine(subject);
            }

            Console.WriteLine("\n Rewriting Example  using SQL like syntax.\n"); 
            IEnumerable<string> allSubjectsSqlDis = (from student in Students.GetAllStudetns()
                                   from subject in student.Subjects
                                   select subject).Distinct();

            foreach (string subject in allSubjectsSqlDis)
            {
                Console.WriteLine(subject);
            }

            Console.WriteLine("\nSelects student name along with all the subjects.\n");
            var result2 = Students.GetAllStudetns().SelectMany(s => s.Subjects, (student, subject) =>
                         new { StudentName = student.Name, Subject = subject });

            foreach (var v in result2)
            {
                Console.WriteLine(v.StudentName + " - " + v.Subject);
            }

            Console.WriteLine("\nRewriting Example  using SQL like syntax.\n");
            var result4 = from student in Students.GetAllStudetns()
                          from subject in student.Subjects
                          select new { StudnetName = student.Name, Subject = subject };

            foreach (var v in result4)
            {
                Console.WriteLine(v.StudnetName + " - " + v.Subject);
            }
        }

        
        
        
        
        
        
        
        
        public static void OrderingOperators()
        {
            Console.WriteLine("\n************************************Odering Operators*****************************************\n");

            //https://csharp-video-tutorials.blogspot.com/2014/07/part-10-ordering-operators-in-linq_13.html
            //https://csharp-video-tutorials.blogspot.com/2014/07/part-11-ordering-operators-in-linq-ii.html

            //The following 5 standard LINQ query operators belong to Ordering Operators category
            //OrderBy
            //OrderByDescending
            //ThenBy
            //ThenByDescending
            //Reverse

            Console.WriteLine("\nOrderBy\n");
            Console.WriteLine("\nSort Students by Name in ascending order\n");
            IEnumerable<StudentsOrder> result = StudentsOrder.GetAllStudents().OrderBy(s => s.Name);
            foreach (StudentsOrder student in result)
            {
                Console.WriteLine(student.Name);
            }

            Console.WriteLine("\nRewriting using SQL like syntax\n");
            IEnumerable <StudentsOrder> result1 = from student in StudentsOrder.GetAllStudents()
                                                 orderby student.Name
                                                 select student;

            foreach (StudentsOrder student in result1)
            {
                Console.WriteLine(student.Name);
            }

            Console.WriteLine("\nSortByDecending\n");
            Console.WriteLine("\nSort Students by Name in descending order\n");
            IEnumerable <StudentsOrder> result2 = StudentsOrder.GetAllStudents().OrderByDescending(s => s.Name);
            foreach (StudentsOrder student in result2)
            {
                Console.WriteLine(student.Name);
            }


            Console.WriteLine("\nRewriting using SQL like syntax\n");
            IEnumerable <StudentsOrder> result3 = from student in StudentsOrder.GetAllStudents()
                              orderby student.Name descending
                              select student;

            foreach (StudentsOrder student in result3)
            {
                Console.WriteLine(student.Name);
            }

            Console.WriteLine("\nThenBy\n");

            IEnumerable<StudentsOrder> result4 = StudentsOrder.GetAllStudents()
                                                .OrderBy(s => s.TotalMarks).ThenBy(s => s.Name).ThenBy(s => s.StudentID);
            foreach (StudentsOrder student in result4)
            {
                Console.WriteLine(student.TotalMarks + "\t" + student.Name + "\t" + student.StudentID);
            }

            Console.WriteLine("\nThenBy Using Sql Syntax\n");

            IEnumerable<StudentsOrder> result5 = from student in StudentsOrder.GetAllStudents()
                                          orderby student.TotalMarks, student.Name, student.StudentID
                                          select student;
            foreach (StudentsOrder student in result5)
            {
                Console.WriteLine(student.TotalMarks + "\t" + student.Name + "\t" + student.StudentID);
            }

            Console.WriteLine("\nReverses the items in the collection.\n");

            IEnumerable <StudentsOrder> students = StudentsOrder.GetAllStudents();

            Console.WriteLine("Before calling Reverse\n");
            foreach (StudentsOrder s in students)
            {
                Console.WriteLine(s.StudentID + "\t" + s.Name + "\t" + s.TotalMarks);
            }

            Console.WriteLine();
            IEnumerable<StudentsOrder> result6 = students.Reverse();

            Console.WriteLine("After calling Reverse\n");
            foreach (StudentsOrder s in result)
            {
                Console.WriteLine(s.StudentID + "\t" + s.Name + "\t" + s.TotalMarks);
            }



        }

        
        
        
        
        
        public static void PartationingOperators()
        {
            Console.WriteLine("\n************************************Partationing Operators*****************************************\n");

            //https://csharp-video-tutorials.blogspot.com/2014/07/part-12-partitioning-operators-in-linq.html

            //The following 4 standard LINQ query operators belong to Partitioning Operators category
            //Take
            //Skip
            //TakeWhile
            //SkipWhile

            Console.WriteLine("\nTake method returns a specified number of elements from the start of the collection.\n The number of items to return is specified using the count parameter this method expects.\n");
            Console.WriteLine("\nRetrieves only the first 3 countries of the array.\n");

            string[] countries = { "Australia", "Canada", "Germany", "US", "India", "UK", "Italy" };

            IEnumerable<string> result = countries.Take(3);

            foreach (string country in result)
            {
                Console.WriteLine(country);
            }
            Console.WriteLine("\nRewriting using SQL like syntax\n");

            IEnumerable<string> result1 = (from country in countries
                                          select country).Take(3);

            foreach (string country in result1)
            {
                Console.WriteLine(country);
            }

            Console.WriteLine("\nSkip method skips a specified number of elements in a collection and then returns the remaining elements. The number of items to skip is specified using the count parameter this method expects.\n");
            Console.WriteLine("\nSkips the first 3 countries and retrieves the rest of them\n");

            IEnumerable<string> result2 = countries.Skip(3);

            foreach (string country in result2)
            {
                Console.WriteLine(country);
            }

            Console.WriteLine("\nTakeWhile method returns elements from a collection as long as the given condition specified by the predicate is true.\n");
            Console.WriteLine("\nReturn countries starting from the beginning of the array until a country name is hit that does not have length greater than 2 characters.\n");


            IEnumerable<string> result3 = countries.TakeWhile(s => s.Length > 2);

            foreach (string country in result3)
            {
                Console.WriteLine(country);
            }






            Console.WriteLine("\nSkipWhile method skips elements in a collection as long as the given condition specified by the predicate is true, and then returns the remaining elements.\n");

            IEnumerable<string> result5 = countries.SkipWhile(s => s.Length > 2);

            foreach (string country in result5)
            {
                Console.WriteLine(country);
            }
        }

        
        
        
        
        
        
        
        
        
        public static void ConversionOperators()
        {
            Console.WriteLine("\n***********************************Conversion Operators******************************************\n");

            //https://csharp-video-tutorials.blogspot.com/2014/07/part-15-conversion-operators-in-linq.html
            //https://csharp-video-tutorials.blogspot.com/2014/07/part-16-cast-and-oftype-operators-in.html

            //The following standard LINQ query operators belong to Conversion Operators category
            //ToList
            //ToArray
            //ToDictionary
            //ToLookup
            //Cast
            //OfType
            //AsEnumerable
            //AsQueryable

            Console.WriteLine("\n**************ToList***************\n");
            Console.WriteLine("ToList operator extracts all of the items from the source sequence and returns a new List<T>.\n");

            int[] numbers = { 1, 2, 3, 4, 5 };

            List<int> result = numbers.ToList();

            foreach (int i in result)
            {
                Console.WriteLine(i);
            }


            Console.WriteLine("\n*****************ToArray*************\n");
            Console.WriteLine("\nToArray operator extracts all of the items from the source sequence and returns a new Array.\n");
            List<string> countries = new List<string> { "US", "India", "UK", "Australia", "Canada" };

            string[] result1 = (from country in countries
                               orderby country ascending
                               select country).ToArray();

            foreach (string str in result1)
            {
                Console.WriteLine(str);
            }

            Console.WriteLine("\n*********ToDictionary**************\n");
            Console.WriteLine("\nToDictionary operator extracts all of the items from the source sequence and returns a new Dictionary.\n");
            
            IEnumerable<StudentsOrder> studentTmp = StudentsOrder.GetAllStudents();
            
            Dictionary<int, string> result2 = studentTmp.ToDictionary(x => x.StudentID, x => x.Name);

            foreach (KeyValuePair<int, string> kvp in result2)
            {
                Console.WriteLine(kvp.Key + " " + kvp.Value);
            }

            Console.WriteLine("\nWith Object As Value\n");
            Dictionary<int, StudentsOrder> result3 = studentTmp.ToDictionary(x => x.StudentID);

            foreach (KeyValuePair<int, StudentsOrder> kvp in result3)
            {
                Console.WriteLine(kvp.Key + "\t" + kvp.Value.Name + "\t" + kvp.Value.TotalMarks);
            }


            Console.WriteLine("\nToLookUp\n");
            Console.WriteLine("\nToLookup creates a Lookup. Just like a dictionary, a Lookup is a collection of key/ value pairs.\nA dictionary cannot contain keys with identical values, where as a Lookup can.\n");
            List<EmployeeDemo> listEmployees = new List<EmployeeDemo>
            {
                new EmployeeDemo() { Name = "Ben", JobTitle = "Developer", City = "London" },
                new EmployeeDemo() { Name = "John", JobTitle = "Sr. Developer", City = "Bangalore" },
                new EmployeeDemo() { Name = "Steve", JobTitle = "Developer", City = "Bangalore" },
                new EmployeeDemo() { Name = "Stuart", JobTitle = "Sr. Developer", City = "London" },
                new EmployeeDemo() { Name = "Sara", JobTitle = "Developer", City = "London" },
                new EmployeeDemo() { Name = "Pam", JobTitle = "Developer", City = "London" }
            };

            // Group employees by JobTitle

            var employeesByJobTitle = listEmployees.ToLookup(x => x.JobTitle);

            Console.WriteLine("Employees Grouped By JobTitle");
            foreach (var kvp in employeesByJobTitle)
            {
                Console.WriteLine(kvp.Key);
                // Lookup employees by JobTitle
                foreach (var item in employeesByJobTitle[kvp.Key])
                {
                    Console.WriteLine("\t" + item.Name + "\t" + item.JobTitle + "\t" + item.City);
                }
            }

            Console.WriteLine(); Console.WriteLine();

            // Group employees by City
            var employeesByCity = listEmployees.ToLookup(x => x.City);

            Console.WriteLine("Employees Grouped By City");
            foreach (var kvp in employeesByCity)
            {
                Console.WriteLine(kvp.Key);
                // Lookup employees by City
                foreach (var item in employeesByCity[kvp.Key])
                {
                    Console.WriteLine("\t" + item.Name + "\t" + item.JobTitle + "\t" + item.City);
                }
            }

            Console.WriteLine("\n************Cast***********\n");
            ArrayList list = new ArrayList();
            list.Add(1);
            list.Add(2);
            list.Add(3);

            // The following item causes an exception
            // list.Add("ABC");

            IEnumerable<int> result5 = list.Cast<int>();

            foreach (int i in result5)
            {
                Console.WriteLine(i);
            }


            Console.WriteLine("\n**********OfType*************\n");

            ArrayList list1 = new ArrayList();
            list1.Add(1);
            list1.Add(2);
            list1.Add(3);
            list1.Add("4");
            list1.Add("ABC");

            IEnumerable<int> result6 = list1.OfType<int>();

            foreach (int i in result6)
            {
                Console.WriteLine(i);
            }
        }
    

        

        
        
        
        
        
        
        public static void GroupingOperators()
        {
            //https://csharp-video-tutorials.blogspot.com/2014/07/part-18-groupby-in-linq.html
            //https://csharp-video-tutorials.blogspot.com/2014/07/part-19-group-by-multiple-keys-in-linq.html
            Console.WriteLine("\n****************************************Grouping Operators*************************************\n");

            Console.WriteLine("\nGroupBy operator belong to Grouping Operators category. This operator takes a flat sequence of items, organize that sequence into groups (IGrouping<K,V>) based on a specific key and return groups of sequences. \n");

            Console.WriteLine("\nGet Employee Count By Department\n");
            var employeeGroup = from employee in EmployeeGroup.GetAllEmployees()
                                group employee by employee.Department;

            foreach (var groupemp in employeeGroup)
            {
                Console.WriteLine("{0} - {1}", groupemp.Key, groupemp.Count());
            }


            Console.WriteLine("\nGet Employee Count By Department and also each employee and department name\n");
            var employeeGroup1 = from employee in EmployeeGroup.GetAllEmployees()
                                group employee by employee.Department;

            foreach (var groupemp1 in employeeGroup1)
            {
                Console.WriteLine("{0} - {1}", groupemp1.Key, groupemp1.Count());
                Console.WriteLine("----------");
                foreach (var employee in groupemp1)
                {
                    Console.WriteLine(employee.Name + "\t" + employee.Department);
                }
                Console.WriteLine(); Console.WriteLine();
            }
            Console.WriteLine("Group employees by Department and then by Gender. \nThe employee groups should be sorted first by Department and then by Gender in ascending order.\nAlso, employees within each group must be sorted in ascending order by Name.\n");
            var employeeGroups = EmployeeGroup.GetAllEmployees()
                                 .GroupBy(x => new { x.Department, x.Gender })
                                 .OrderBy(g => g.Key.Department).ThenBy(g => g.Key.Gender)
                                 .Select(g => new
                                  {
                                     Dept = g.Key.Department,
                                     Gender = g.Key.Gender,
                                     Employees = g.OrderBy(x => x.Name)
                                  });

            foreach (var groupemp3 in employeeGroups)
            {
                Console.WriteLine("{0} department {1} employees count = {2}",
                    groupemp3.Dept, groupemp3.Gender, groupemp3.Employees.Count());


                Console.WriteLine("--------------------------------------------");
                foreach (var employee in groupemp3.Employees)
                {
                    Console.WriteLine(employee.Name + "\t" + employee.Gender
                        + "\t" + employee.Department);
                }
                Console.WriteLine(); Console.WriteLine();
            }
            Console.WriteLine("\nRewriting Example  using SQL like syntax\n");
            var employeeGroups1 = from employee in EmployeeGroup.GetAllEmployees()
                                 group employee by new
                                 {
                                     employee.Department,
                                     employee.Gender
                                 } into eGroup
                                 orderby eGroup.Key.Department ascending,
                                         eGroup.Key.Gender ascending
                                 select new
                                 {
                                     Dept = eGroup.Key.Department,
                                     Gender = eGroup.Key.Gender,
                                     Employees = eGroup.OrderBy(x => x.Name)
                                 };

            foreach (var groupemp2 in employeeGroups1)
            {
                Console.WriteLine("{0} department {1} employees count = {2}",
                    groupemp2.Dept, groupemp2.Gender, groupemp2.Employees.Count());


                Console.WriteLine("--------------------------------------------");
                foreach (var employee in groupemp2.Employees)
                {
                    Console.WriteLine(employee.Name + "\t" + employee.Gender
                        + "\t" + employee.Department);
                }
                Console.WriteLine(); Console.WriteLine();
            }

        }
        public static void demo()
        {
            Console.WriteLine("\n*****************************************************************************\n");
        }
    }
}
