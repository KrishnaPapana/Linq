﻿using LinqJoins.Models;
using System;
using System.Linq;

namespace LinqJoins
{
    class Program
    {
        static void Main(string[] args)
        {
            GroupJoin();
            InnerJoin();
            LeftOuterJoin();
            CrossJoin();
        }
        public static void GroupJoin()
        {
            //The following are the different types of joins in LINQ
            //Group Join
            //Inner Join
            //Left Outer Join
            //Cross Join

            Console.WriteLine("**********************GroupJoin******************************\n");
            Console.WriteLine("Group Join produces hierarchical data structures.\n Each element from the first collection is paired with a set of correlated elements from the second collection. ");
            Console.WriteLine("\nGroup employees by Department.\n");
            var employeesByDepartment = Department.GetAllDepartments()
                                        .GroupJoin(Employee.GetAllEmployees(),
                                        d => d.ID,
                                        e => e.DepartmentID,
                                        (department, employees) => new
                                        {
                                            Department = department,
                                            Employees = employees
                                        });

            foreach (var department in employeesByDepartment)
            {
                Console.WriteLine(department.Department.Name);
                foreach (var employee in department.Employees)
                {
                    Console.WriteLine(" " + employee.Name);
                }
                Console.WriteLine();
            }

            Console.WriteLine("\nUsing Sql Syntax");
            var employeesByDepartment1 = from d in Department.GetAllDepartments()
                                        join e in Employee.GetAllEmployees()
                                        on d.ID equals e.DepartmentID into eGroup
                                        select new
                                        {
                                            Department = d,
                                            Employees = eGroup
                                        };
            foreach (var department in employeesByDepartment1)
            {
                Console.WriteLine(department.Department.Name);
                foreach (var employee in department.Employees)
                {
                    Console.WriteLine(" " + employee.Name);
                }
                Console.WriteLine();
            }

        }

        public static void InnerJoin()
        {
            //The following are the different types of joins in LINQ
            //Group Join
            //Inner Join
            //Left Outer Join
            //Cross Join

            Console.WriteLine("**********************InnerJoin******************************\n");
            Console.WriteLine("INNER JOIN in LINQ. If you have 2 collections, and when you perform an inner join,\nthen only the matching elements between the 2 collections are included in the result set.\nNon - Matching elements are excluded from the result set.\n");
            Console.WriteLine("\nJoin the Employees and Department collections and print all the Employees and their respective department names.\n");
            var result = Employee.GetAllEmployees().Join(Department.GetAllDepartments(),
                                        e => e.DepartmentID,
                                        d => d.ID, (employee, department) => new
                                        {
                                            EmployeeName = employee.Name,
                                            DepartmentName = department.Name
                                        });
            foreach (var employee in result)
            {
                Console.WriteLine(employee.EmployeeName + "\t" + employee.DepartmentName);
            }


            Console.WriteLine("\nUsing Sql Syntax");
            var result1 = from e in Employee.GetAllEmployees()
                         join d in Department.GetAllDepartments()
                         on e.DepartmentID equals d.ID
                         select new
                         {
                             EmployeeName = e.Name,
                             DepartmentName = d.Name
                         };

            foreach (var employee in result1)
            {
                Console.WriteLine(employee.EmployeeName + "\t" + employee.DepartmentName);
            }


        }
        public static void LeftOuterJoin()
        {
            Console.WriteLine("\n********************************LeftOuterJoin**********************************\n");
            Console.WriteLine("\nImplement a Left Outer Join between Employees and Department collections and print all the Employees and their respective department names.\n Employees without a department, should display No Department against their name.\n");
            var result = from e in Employee.GetAllEmployees()
                         join d in Department.GetAllDepartments()
                         on e.DepartmentID equals d.ID into eGroup
                         from d in eGroup.DefaultIfEmpty()
                         select new
                         {
                            EmployeeName = e.Name,
                            DepartmentName = d == null ? "No Department" : d.Name
                         };

            foreach (var v in result)
            {
                Console.WriteLine(v.EmployeeName + "\t" + v.DepartmentName);
            }


            Console.WriteLine("\nusing extension method syntax.\n");

            Console.WriteLine("To implement Left Outer Join, with extension method syntax we use the GroupJoin() method along with SelectMany() and DefaultIfEmpty() methods.");
            var result1 = Employee.GetAllEmployees()
                        .GroupJoin(Department.GetAllDepartments(),
                                e => e.DepartmentID,
                                d => d.ID,
                                (emp, depts) => new { emp, depts })
                        .SelectMany(z => z.depts.DefaultIfEmpty(),
                                (a, b) => new
                                {
                                    EmployeeName = a.emp.Name,
                                    DepartmentName = b == null ? "No Department" : b.Name
                                });

            foreach (var v in result1)
            {
                Console.WriteLine(" " + v.EmployeeName + "\t" + v.DepartmentName);
            }

            
        }

        public static void CrossJoin()
        {
            Console.WriteLine("\nCross join produces a cartesian product i.e when we cross join two sequences, every element in the first collection is combined with every element in the second collection.\nThe total number of elements in the resultant sequence will always be equal to the product of the elements in the two source sequences.\nThe on keyword that specfies the JOIN KEY is not required.");
            Console.WriteLine("\nCross Join Employees collection with Departments collections.\n");
            var result = from e in Employee.GetAllEmployees()
                         from d in Department.GetAllDepartments()
                         select new { e, d };

            foreach (var v in result)
            {
                Console.WriteLine(v.e.Name + "\t" + v.d.Name);
            }


            Console.WriteLine("\nCross Join Departments collections with Employees collection\n");
            var result1 = from d in Department.GetAllDepartments()
                          from e in Employee.GetAllEmployees()
                          select new { e, d };

            foreach (var v in result1)
            {
                Console.WriteLine(v.e.Name + "\t" + v.d.Name);
            }

            Console.WriteLine("\nusing extension method syntax\n");

            Console.WriteLine("\nTo implement Cross Join using extension method syntax, we could either use SelectMany() method or Join() method\n");

            Console.WriteLine("\nImplementing cross join using SelectMany()\n"); 
            var result2 = Employee.GetAllEmployees()
                          .SelectMany(e => Department.GetAllDepartments(), (e, d) => new { e, d });

            foreach (var v in result2)
            {
                Console.WriteLine(v.e.Name + "\t" + v.d.Name);
            }

            Console.WriteLine("\nImplementing cross join using Join()\n");
            var result3 = Employee.GetAllEmployees()
                                     .Join(Department.GetAllDepartments(),
                                               e => true,
                                               d => true,
                                               (e, d) => new { e, d });

            foreach (var v in result3)
            {
                Console.WriteLine(v.e.Name + "\t" + v.d.Name);
            }
        }
    }
}
