﻿namespace CaseStudy1.Models
{
    public class AuthenticationDescription
    {
    }
}