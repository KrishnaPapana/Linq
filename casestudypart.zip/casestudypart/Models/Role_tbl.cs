﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.ComponentModel;

namespace CaseStudy1.Models
{
    public class Role_tbl
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
    }
}