﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.ComponentModel;

namespace CaseStudy1.Models
{
    public class User_tbl
    {
        public int ID { get; set; }

        [Display(Name = "User ID")]
        public string UserID { get; set; }

        public string UserName { get; set; }
        public string Password { get; set; }

        public int RoleID { get; set; }
        public Role_tbl role_Tbl { get; set; }
    }
}