﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.ComponentModel;

namespace CaseStudy1.Models
{
    public class CRUD_Context:DbContext
    {
        public CRUD_Context() : base("LoginValidationEntities")
        {

        }
        public DbSet<User_tbl> User_Tbls { get; set; }
        public DbSet<Role_tbl> Role_Tbls { get; set; }

        public DbSet<Item> Items { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Producer> Producers { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<Order> Orders { get; set; }

        public DbSet<OrderDetail> OrderDetails  { get; set; }




    }
}