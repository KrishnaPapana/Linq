﻿using CaseStudy1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace CaseStudy1.Infrastructure
{
    public class CustomAuthorizeAttribute : AuthorizeAttribute
    {

        private readonly string[] allowedroles;
        public CustomAuthorizeAttribute(params string[] roles)
        {
            this.allowedroles = roles;
        }
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            bool authorize = false;
            var userId = Convert.ToString(httpContext.Session["UserID"]);
            if (!string.IsNullOrEmpty(userId))
                using (var context = new CRUD_Context())
                {
                    var userRole = (from u in context.User_Tbls
                                    join r in context.Role_Tbls on u.RoleID equals r.Id
                                    where u.UserID == userId
                                    select new
                                    {
                                        r.Name
                                    }).FirstOrDefault();
                    foreach (var role in allowedroles)
                    {
                        if (role == userRole.Name) return true;
                    }
                }
            return authorize;
        }




        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            filterContext.Result = new RedirectToRouteResult(
            new RouteValueDictionary
                     {
                           { "controller", "StoreManager" },
                           { "action", "UnAuthorized" }
                      });
        }

    }
}