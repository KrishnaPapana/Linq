﻿using CaseStudy1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CaseStudy1.Common;

namespace CaseStudy1.Controllers
{
    public class HomeController : Controller
    {
        CRUD_Context StoreDB = new CRUD_Context();

        private List<Item> GetTopSellingItems(int count)
        {
            return StoreDB.Items.OrderByDescending(i => i.OrderDetails.Count())
                .Take(count)
                .ToList();
        }
        [TrackExecutionTime]
        public ActionResult Index()
        {
            var items = GetTopSellingItems(10);
            return View(items);
        }
        [TrackExecutionTime]
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }
        [TrackExecutionTime]
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}