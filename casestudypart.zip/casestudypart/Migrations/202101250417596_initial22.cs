namespace CaseStudy1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initial22 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Orders", "CardNum", c => c.String(nullable: false));
            AlterColumn("dbo.Orders", "CVV", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Orders", "CVV", c => c.String());
            AlterColumn("dbo.Orders", "CardNum", c => c.String());
        }
    }
}
