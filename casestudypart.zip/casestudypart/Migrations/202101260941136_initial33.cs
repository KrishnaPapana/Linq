namespace CaseStudy1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initial33 : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
